package com.my.mall;

public interface IMall {
	//abstract method
	void setTitle(String title);
	void genUser();
	void genProduct();
	void start();
}
