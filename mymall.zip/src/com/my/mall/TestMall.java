package com.my.mall;

public class TestMall {

	public static void main(String[] args) {

		System.out.println(PayType.CASH);
		System.out.println(PayType.CASH.ordinal());
		System.out.println(PayType.CARD);
		//�����Ǵ� ������ ���
		System.out.println(PayType.CARD.ordinal());
		
		
	}

}
